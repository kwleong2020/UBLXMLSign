﻿using System.Runtime.ConstrainedExecution;
using System.Runtime.Intrinsics;
using System.Xml;
using System.Xml.Linq;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //your UBL xml file @ v1.0
            XDocument xmlDoc = XDocument.Load(@"C:\ErrorLog\eInvoice\BankULB.xml");
            XElement root = xmlDoc.Root;

            root.Add(new XAttribute(XNamespace.Xmlns + "ext", "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2"));

            //< param name = "certPath" >your cert folder directory</ param > sample : E:\\eInvoiceProject\\GitLab\\HLB_Cert.p12
            //< param name = "certPass" > your cert password </ param > sample : XIIRE233
            //< param name = "docXML" > v1.0 xml string</ param > 
            //< param name = "destPath" > new folder to store v1.1 ULB file</ param > sample : c:\\ErrorLog\\
            //< param name = "certPass" > v1.1 UBL file name</ param > sample : newXML.xml
            UBLDigitalSign.ULBXMLDigitalSignature.GenerateDigitalSign("E:\\eInvoiceProject\\GitLab\\HLB_Cert.p12", "XIIRE233", root.ToString(), "c:\\ErrorLog\\", "newXML.xml");


        }
    }
}
